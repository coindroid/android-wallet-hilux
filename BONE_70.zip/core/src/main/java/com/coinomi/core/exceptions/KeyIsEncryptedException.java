package com.coinomi.core.exceptions;

/**
 * @author John L. Jegutanis
 */
public class KeyIsEncryptedException extends Exception {
    public KeyIsEncryptedException(Throwable cause) {
        super(cause);
    }
}
