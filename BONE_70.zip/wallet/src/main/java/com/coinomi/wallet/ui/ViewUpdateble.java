package com.coinomi.wallet.ui;

/**
 * @author John L. Jegutanis
 */
public interface ViewUpdateble {
    void updateView();
}
