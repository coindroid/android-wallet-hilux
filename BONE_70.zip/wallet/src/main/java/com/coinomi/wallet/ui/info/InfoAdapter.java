package com.coinomi.wallet.ui.info;

import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.coinomi.wallet.R;

import java.util.ArrayList;
import java.util.Map;

public class InfoAdapter extends BaseAdapter {

    private final ArrayList mData;

    public InfoAdapter(Map<String, String> map) {
        mData = new ArrayList();
        mData.addAll(map.entrySet());
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Map.Entry<String, String> getItem(int position) {
        return (Map.Entry) mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO implement you own logic with ID
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final View result;

        if (convertView == null) {
            result = LayoutInflater.from(parent.getContext()).inflate(R.layout.info_adapter_item, parent, false);
        } else {
            result = convertView;
        }

        Map.Entry<String, String> item = getItem(position);

        // TODO replace findViewById by ViewHolder
        SpannableString contentKey = new SpannableString(item.getKey());
        contentKey.setSpan(new UnderlineSpan(), 0, item.getKey().length(), 0);

        ((TextView) result.findViewById(android.R.id.text1)).setText(contentKey);
        return result;
    }
}