package com.coinomi.wallet.ui.widget;

import android.content.Context;

public class NavDrawerItemViewWithoutCheck extends NavDrawerItemView {

    public NavDrawerItemViewWithoutCheck(Context context) {
        super(context);
    }

    @Override
    public void setChecked(boolean checked) {
    }
}
