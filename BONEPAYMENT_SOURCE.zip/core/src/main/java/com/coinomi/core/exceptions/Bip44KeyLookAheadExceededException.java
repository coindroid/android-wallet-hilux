package com.coinomi.core.exceptions;

/**
 * @author John L. Jegutanis
 */
public class Bip44KeyLookAheadExceededException extends Throwable {
}
