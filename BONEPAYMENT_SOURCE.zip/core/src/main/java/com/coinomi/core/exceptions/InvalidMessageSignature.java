package com.coinomi.core.exceptions;

/**
 * @author John L. Jegutanis
 */
public class InvalidMessageSignature extends Exception {
    public InvalidMessageSignature(Throwable cause) {
        super(cause);
    }
}
