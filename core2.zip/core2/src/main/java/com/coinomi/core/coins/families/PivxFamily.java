package com.coinomi.core.coins.families;

public abstract class PivxFamily extends BitFamily {
    public PivxFamily() {
        this.family = Families.PIVX;
    }
}
